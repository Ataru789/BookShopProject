var namespace_book_shop_1_1_data =
[
    [ "ApplicationDbContext", "class_book_shop_1_1_data_1_1_application_db_context.html", null ],
    [ "DbSeeder", "class_book_shop_1_1_data_1_1_db_seeder.html", null ]
];