var namespace_book_shop_1_1_models =
[
    [ "DTOs", "namespace_book_shop_1_1_models_1_1_d_t_os.html", "namespace_book_shop_1_1_models_1_1_d_t_os" ],
    [ "Book", "class_book_shop_1_1_models_1_1_book.html", null ],
    [ "CartDetail", "class_book_shop_1_1_models_1_1_cart_detail.html", null ],
    [ "ErrorViewModel", "class_book_shop_1_1_models_1_1_error_view_model.html", null ],
    [ "Genre", "class_book_shop_1_1_models_1_1_genre.html", null ],
    [ "Order", "class_book_shop_1_1_models_1_1_order.html", null ],
    [ "OrderDetail", "class_book_shop_1_1_models_1_1_order_detail.html", null ],
    [ "OrderStatus", "class_book_shop_1_1_models_1_1_order_status.html", null ],
    [ "ShoppingCart", "class_book_shop_1_1_models_1_1_shopping_cart.html", null ],
    [ "Stock", "class_book_shop_1_1_models_1_1_stock.html", null ]
];