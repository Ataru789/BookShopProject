var namespace_book_shop =
[
    [ "Constants", "namespace_book_shop_1_1_constants.html", [
      [ "PayMethods", "namespace_book_shop_1_1_constants.html#a08e3765dadf3cd325d3238c263c951ae", [
        [ "COD", "namespace_book_shop_1_1_constants.html#a08e3765dadf3cd325d3238c263c951aea5030551cd5ca2f5644f3d4e00ff6eba7", null ],
        [ "Online", "namespace_book_shop_1_1_constants.html#a08e3765dadf3cd325d3238c263c951aea54f664c70c22054ea0d8d26fc3997ce7", null ]
      ] ],
      [ "Roles", "namespace_book_shop_1_1_constants.html#acdff3798980d699840a16e92663c7a8a", [
        [ "User", "namespace_book_shop_1_1_constants.html#acdff3798980d699840a16e92663c7a8aa8f9bfe9d1345237cb3b2b205864da075", null ],
        [ "Admin", "namespace_book_shop_1_1_constants.html#acdff3798980d699840a16e92663c7a8aae3afed0047b08059d0fada10f400c1e5", null ]
      ] ]
    ] ],
    [ "Controllers", "namespace_book_shop_1_1_controllers.html", "namespace_book_shop_1_1_controllers" ],
    [ "Data", "namespace_book_shop_1_1_data.html", "namespace_book_shop_1_1_data" ],
    [ "Models", "namespace_book_shop_1_1_models.html", "namespace_book_shop_1_1_models" ],
    [ "Repositories", "namespace_book_shop_1_1_repositories.html", "namespace_book_shop_1_1_repositories" ],
    [ "IBookRepository", "interface_book_shop_1_1_i_book_repository.html", null ]
];