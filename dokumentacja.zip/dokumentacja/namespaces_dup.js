var namespaces_dup =
[
    [ "BookShop", "namespace_book_shop.html", "namespace_book_shop" ]
];