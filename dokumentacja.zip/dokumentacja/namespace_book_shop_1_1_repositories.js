var namespace_book_shop_1_1_repositories =
[
    [ "BookRepository", "class_book_shop_1_1_repositories_1_1_book_repository.html", null ],
    [ "CartRepository", "class_book_shop_1_1_repositories_1_1_cart_repository.html", null ],
    [ "GenreRepository", "class_book_shop_1_1_repositories_1_1_genre_repository.html", null ],
    [ "ICartRepository", "interface_book_shop_1_1_repositories_1_1_i_cart_repository.html", null ],
    [ "IGenreRepository", "interface_book_shop_1_1_repositories_1_1_i_genre_repository.html", null ],
    [ "IStockRepository", "interface_book_shop_1_1_repositories_1_1_i_stock_repository.html", null ],
    [ "IUserOrderRepository", "interface_book_shop_1_1_repositories_1_1_i_user_order_repository.html", null ],
    [ "StockRepository", "class_book_shop_1_1_repositories_1_1_stock_repository.html", null ],
    [ "UserOrderRepository", "class_book_shop_1_1_repositories_1_1_user_order_repository.html", null ]
];