var namespace_book_shop_1_1_models_1_1_d_t_os =
[
    [ "BookDisplayModelDTO", "class_book_shop_1_1_models_1_1_d_t_os_1_1_book_display_model_d_t_o.html", null ],
    [ "CheckoutModelDTO", "class_book_shop_1_1_models_1_1_d_t_os_1_1_checkout_model_d_t_o.html", null ],
    [ "GenreDTO", "class_book_shop_1_1_models_1_1_d_t_os_1_1_genre_d_t_o.html", null ],
    [ "OrderDetailModelDTO", "class_book_shop_1_1_models_1_1_d_t_os_1_1_order_detail_model_d_t_o.html", null ],
    [ "StockDisplayModel", "class_book_shop_1_1_models_1_1_d_t_os_1_1_stock_display_model.html", null ],
    [ "StockDTO", "class_book_shop_1_1_models_1_1_d_t_os_1_1_stock_d_t_o.html", null ],
    [ "UpdateOrderStatusModel", "class_book_shop_1_1_models_1_1_d_t_os_1_1_update_order_status_model.html", null ]
];