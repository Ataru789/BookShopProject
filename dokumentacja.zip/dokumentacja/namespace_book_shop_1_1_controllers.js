var namespace_book_shop_1_1_controllers =
[
    [ "AdminController", "class_book_shop_1_1_controllers_1_1_admin_controller.html", null ],
    [ "CartController", "class_book_shop_1_1_controllers_1_1_cart_controller.html", null ],
    [ "GenreController", "class_book_shop_1_1_controllers_1_1_genre_controller.html", null ],
    [ "HomeController", "class_book_shop_1_1_controllers_1_1_home_controller.html", null ],
    [ "StockController", "class_book_shop_1_1_controllers_1_1_stock_controller.html", null ],
    [ "UserOrderController", "class_book_shop_1_1_controllers_1_1_user_order_controller.html", null ]
];