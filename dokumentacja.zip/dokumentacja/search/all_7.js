var searchData=
[
  ['ibookrepository_0',['IBookRepository',['../interface_book_shop_1_1_i_book_repository.html',1,'BookShop']]],
  ['icartrepository_1',['ICartRepository',['../interface_book_shop_1_1_repositories_1_1_i_cart_repository.html',1,'BookShop::Repositories']]],
  ['igenrerepository_2',['IGenreRepository',['../interface_book_shop_1_1_repositories_1_1_i_genre_repository.html',1,'BookShop::Repositories']]],
  ['istockrepository_3',['IStockRepository',['../interface_book_shop_1_1_repositories_1_1_i_stock_repository.html',1,'BookShop::Repositories']]],
  ['iuserorderrepository_4',['IUserOrderRepository',['../interface_book_shop_1_1_repositories_1_1_i_user_order_repository.html',1,'BookShop::Repositories']]]
];
