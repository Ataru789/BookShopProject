var searchData=
[
  ['book_0',['Book',['../class_book_shop_1_1_models_1_1_book.html',1,'BookShop::Models']]],
  ['bookdisplaymodeldto_1',['BookDisplayModelDTO',['../class_book_shop_1_1_models_1_1_d_t_os_1_1_book_display_model_d_t_o.html',1,'BookShop::Models::DTOs']]],
  ['bookrepository_2',['BookRepository',['../class_book_shop_1_1_repositories_1_1_book_repository.html',1,'BookShop::Repositories']]]
];
