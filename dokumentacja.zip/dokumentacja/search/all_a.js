var searchData=
[
  ['roles_0',['Roles',['../namespace_book_shop_1_1_constants.html#acdff3798980d699840a16e92663c7a8a',1,'BookShop::Constants']]]
];
