var searchData=
[
  ['genre_0',['Genre',['../class_book_shop_1_1_models_1_1_genre.html',1,'BookShop::Models']]],
  ['genrecontroller_1',['GenreController',['../class_book_shop_1_1_controllers_1_1_genre_controller.html',1,'BookShop::Controllers']]],
  ['genredto_2',['GenreDTO',['../class_book_shop_1_1_models_1_1_d_t_os_1_1_genre_d_t_o.html',1,'BookShop::Models::DTOs']]],
  ['genrerepository_3',['GenreRepository',['../class_book_shop_1_1_repositories_1_1_genre_repository.html',1,'BookShop::Repositories']]]
];
