var indexSectionsWithContent =
{
  0: "abcdeghioprsu",
  1: "abcdeghiosu",
  2: "b",
  3: "pr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "enums"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Enumerations"
};

