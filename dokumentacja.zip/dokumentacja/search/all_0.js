var searchData=
[
  ['admincontroller_0',['AdminController',['../class_book_shop_1_1_controllers_1_1_admin_controller.html',1,'BookShop::Controllers']]],
  ['applicationdbcontext_1',['ApplicationDbContext',['../class_book_shop_1_1_data_1_1_application_db_context.html',1,'BookShop::Data']]]
];
